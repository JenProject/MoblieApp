package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class FoodTalksThree extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button btnBackFoodTalks3, btnBackToMenu;
    ImageButton btnClickToListenENG3;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_talks_three);

        btnBackFoodTalks3 = (Button) findViewById(R.id.btn_BackToFood3);
        btnBackFoodTalks3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(FoodTalksThree.this, FoodTalksTwo.class);
                startActivity(intent);

            }
        });

        btnBackToMenu = (Button) findViewById(R.id.btn_BackToMenu);
        btnBackToMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(FoodTalksThree.this, FoodChosen.class);
                startActivity(intent);

            }
        });

        TextView FoodConvoENG3;

        FoodConvoENG3 = findViewById(R.id.TransportFoodENG3);
        FoodConvoENG3.setText(getString(R.string.FoodConversationENG7) + "\n \n"+ getString(R.string.FoodConversationENG8) +
                "\n \n" + getString(R.string.FoodConversationENG9));

        TextView FoodConvoPL3;

        FoodConvoPL3 = findViewById(R.id.TransportFoodPL3);
        FoodConvoPL3.setText(getString(R.string.FoodConversationPL7) + "\n \n"+ getString(R.string.FoodConversationPL8) +
                "\n \n" + getString(R.string.FoodConversationPL9));
        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG3 = (ImageButton) findViewById(R.id.btn_PushToListenFoodTalkENG3);
        btnClickToListenENG3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.FoodConversationENG7),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.FoodConversationENG8),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.FoodConversationENG9),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
