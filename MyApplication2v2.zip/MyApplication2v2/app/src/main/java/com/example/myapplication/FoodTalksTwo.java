package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class FoodTalksTwo extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Button btnNextFoodTalks2, btnBackToFood2;
    ImageButton btnClickToListenENG2;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_talks_two);

        btnNextFoodTalks2 = (Button) findViewById(R.id.btn_NextFoodTalk2);
        btnNextFoodTalks2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(FoodTalksTwo.this, FoodTalksThree.class);
                startActivity(intent);

            }
        });

        btnBackToFood2 = (Button) findViewById(R.id.btn_BackToFood2);
        btnBackToFood2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(FoodTalksTwo.this, FoodTalksOne.class);
                startActivity(intent);

            }
        });

        TextView FoodConvoENG2;

        FoodConvoENG2 = findViewById(R.id.TransportFoodENG2);
        FoodConvoENG2.setText(getString(R.string.FoodConversationENG4) + "\n \n"+ getString(R.string.FoodConversationENG5) +
                "\n \n" + getString(R.string.FoodConversationENG6));

        TextView FoodConvoPL2;

        FoodConvoPL2 = findViewById(R.id.TransportFoodPL2);
        FoodConvoPL2.setText(getString(R.string.FoodConversationPL4) + "\n \n"+ getString(R.string.FoodConversationPL5) +
                "\n \n" + getString(R.string.FoodConversationPL6));
        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG2 = (ImageButton) findViewById(R.id.btn_PushToListenFoodTalkENG2);
        btnClickToListenENG2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.FoodConversationENG4),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.FoodConversationENG5),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.FoodConversationENG6),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
