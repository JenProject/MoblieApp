package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class MedicTalksTwo extends AppCompatActivity implements TextToSpeech.OnInitListener {
    Button btnNextMedicTalks2, btnBackToMedic2;
    ImageButton btnClickToListenENG2;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medic_talks_two);

        btnNextMedicTalks2 = (Button) findViewById(R.id.btn_NextMedicTalk2);
        btnNextMedicTalks2.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    Intent intent = new Intent(MedicTalksTwo.this, MedicTalksThree.class);
                    startActivity(intent);

                }
            });

        btnBackToMedic2 = (Button) findViewById(R.id.btn_BackToMedic2);
        btnBackToMedic2.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    Intent intent = new Intent(MedicTalksTwo.this, MedicTalksOne.class);
                    startActivity(intent);

                }
            });

        TextView MedicConvoENG2;

        MedicConvoENG2 = findViewById(R.id.TransportMedicENG2);
        MedicConvoENG2.setText(getString(R.string.MedicConversationENG4) + "\n \n"+ getString(R.string.MedicConversationENG5) +
                "\n \n" + getString(R.string.MedicConversationENG6));

        TextView MedicConvoPL2;

        MedicConvoPL2 = findViewById(R.id.TransportMedicPL2);
        MedicConvoPL2.setText(getString(R.string.MedicConversationPL4) + "\n \n"+ getString(R.string.MedicConversationPL5) +
                "\n \n" + getString(R.string.MedicConversationPL6));

        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG2 = (ImageButton) findViewById(R.id.btn_PushToListenMedicTalkENG2);
        btnClickToListenENG2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.MedicConversationENG4),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.MedicConversationENG5),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.MedicConversationENG6),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
