package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.CategoryChosen1;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public final class QuizTransport extends AppCompatActivity {

    TextView questionLabel, questionCountLabel, scoreLabel;
    EditText answerEdt;
    Button submitButton;
    ProgressBar progressBar;
    ArrayList<QuestionModel> questionModelArraylist;

    int currentPosition = 0;
    int numberOfCorrectAnswer = 0;
    ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_transport);


        back = (ImageButton) findViewById(R.id.btn_BackToMenu2);
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(QuizTransport.this, CategoryChosen1.class);
                startActivity(intent);
            }

        });
        // przypisywanie po ID
        questionCountLabel = findViewById(R.id.noQuestion);
        questionLabel = findViewById(R.id.question);
        scoreLabel = findViewById(R.id.score);

        answerEdt = findViewById(R.id.answer);
        submitButton = findViewById(R.id.submit);
        progressBar = findViewById(R.id.progress);

        questionModelArraylist = new ArrayList<>();

        setUpQuestion();

        setData();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                checkAnswer();
            }
        });

        answerEdt.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                Log.e("event.getAction()",event.getAction()+"");
                Log.e("event.keyCode()",keyCode+"");
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {

                    checkAnswer();
                    return true;
                }
                return false;
            }
        });

    }
    public void checkAnswer(){
        String answerString  = answerEdt.getText().toString().trim();

        // przydzielanie score i alerty jesli odp dobra
        if(answerString.equalsIgnoreCase(questionModelArraylist.get(currentPosition).getAnswer())){
            numberOfCorrectAnswer ++;

            new SweetAlertDialog(QuizTransport.this, SweetAlertDialog.SUCCESS_TYPE)
                    .setTitleText("Good job!")
                    .setContentText("Right Asswer")
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            currentPosition ++;

                            setData();
                            answerEdt.setText("");
                            sweetAlertDialog.dismiss();
                        }
                    })
                    .show();


        }else {
            // alert , wyswietl prawidlowa i zmien nazwe buttona jesli zla
            new SweetAlertDialog(QuizTransport.this, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("Wrong Answer")
                    .setContentText("The right answer is : "+questionModelArraylist.get(currentPosition).getAnswer())
                    .setConfirmText("OK")
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {
                            sDialog.dismiss();

                            currentPosition ++;

                            setData();
                            answerEdt.setText("");
                        }
                    })
                    .show();
        }

        int x = ((currentPosition+1) * 100) / questionModelArraylist.size();

        progressBar.setProgress(x);

    }

    // ustawianie pytan
    public void setUpQuestion(){

        questionModelArraylist.add(new QuestionModel("Napisz jak mówimy 'pies' po angielsku? ","dog"));
        questionModelArraylist.add(new QuestionModel("Lot 'odwolany' to... ","canceled"));
        questionModelArraylist.add(new QuestionModel("How much does a zoo 'bilet' cost?","ticket"));
        questionModelArraylist.add(new QuestionModel("Spytaj: Gdzie odbywa się odprawa? ","Where is passport control done"));
        questionModelArraylist.add(new QuestionModel("Jak powiesz: Zgubiłem klucze do mojego pokoju?","I lost my room keys"));



    }
    // pobiera wielkosc array i ustawia ograniczenie, jesli po ostatnm pytaniu
    // zmiana nazw przyciskow, wyswietlenie wyniku
    public void setData(){

        if(questionModelArraylist.size()>currentPosition) {

            questionLabel.setText(questionModelArraylist.get(currentPosition).getQuestionString());

            scoreLabel.setText("Score :" + numberOfCorrectAnswer + "/" + questionModelArraylist.size());
            questionCountLabel.setText("Question No : " + (currentPosition + 1));

        }else{

            SweetAlertDialog sweetAlertDialog = new SweetAlertDialog(QuizTransport.this, SweetAlertDialog.SUCCESS_TYPE);
            sweetAlertDialog.setTitleText("Well done!                                     You completed the quiz.");
            sweetAlertDialog.setContentText("Your score: " + numberOfCorrectAnswer + "/" + questionModelArraylist.size());
            sweetAlertDialog.setConfirmText("Restart");
            sweetAlertDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog) {

                    sDialog.dismissWithAnimation();
                    currentPosition = 0;
                    numberOfCorrectAnswer = 0;
                    progressBar.setProgress(0);
                    setData();
                }
            });
            sweetAlertDialog.setCancelText("Close");
            sweetAlertDialog.setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sDialog) {

                    sDialog.dismissWithAnimation();
                    finish();
                }
            });
            sweetAlertDialog.show();

        }

    }



}
