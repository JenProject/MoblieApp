package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class ShoppingTalksOne extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Button btnBackToShopping1, btnNextShoppingTalks1;
    ImageButton btnClickToListenENG1;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_talks_one);



        btnBackToShopping1 = (Button) findViewById(R.id.btn_BackToShopping1);
        btnBackToShopping1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksOne.this, ShoppingChosen.class);
                startActivity(intent);

            }
        });

        btnNextShoppingTalks1 = (Button) findViewById(R.id.btn_NextShoppingTalk1);
        btnNextShoppingTalks1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksOne.this, ShoppingTalksTwo.class);
                startActivity(intent);

            }
        });

        TextView ShoppingConvoENG1;

        ShoppingConvoENG1 = findViewById(R.id.TransportShoppingENG1);
        ShoppingConvoENG1.setText(getString(R.string.ShoppingConversationENG1) + "\n \n"+ getString(R.string.ShoppingConversationENG2) +
                "\n \n" + getString(R.string.ShoppingConversationENG3));

        TextView ShoppingConvoPL1;

        ShoppingConvoPL1 = findViewById(R.id.TransportShoppingPL1);
        ShoppingConvoPL1.setText(getString(R.string.ShoppingConversationPL1) + "\n \n"+ getString(R.string.ShoppingConversationPL2) +
                "\n \n" + getString(R.string.ShoppingConversationPL3));

        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG1 = (ImageButton) findViewById(R.id.btn_PushToListenShoppingTalkENG1);
        btnClickToListenENG1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.ShoppingConversationENG1),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.ShoppingConversationENG2),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.ShoppingConversationENG3),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
