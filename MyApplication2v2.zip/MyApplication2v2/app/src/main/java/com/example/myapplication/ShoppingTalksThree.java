package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class ShoppingTalksThree extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Button btnBackToShopping3, btnBackToMenu;
    ImageButton btnClickToListenENG3;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_talks_three);

        btnBackToShopping3 = (Button) findViewById(R.id.btn_BackToShopping3);
        btnBackToShopping3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksThree.this, ShoppingTalksTwo.class);
                startActivity(intent);

            }
        });

        btnBackToMenu = (Button) findViewById(R.id.btn_BackToMenu);
        btnBackToMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksThree.this, MainActivity.class);
                startActivity(intent);

            }
        });

        TextView ShoppingConvoENG3;

        ShoppingConvoENG3 = findViewById(R.id.TransportShoppingENG3);
        ShoppingConvoENG3.setText(getString(R.string.ShoppingConversationENG7) + "\n \n"+ getString(R.string.ShoppingConversationENG8) +
                "\n \n" + getString(R.string.ShoppingConversationENG9));

        TextView ShoppingConvoPL3;

        ShoppingConvoPL3 = findViewById(R.id.TransportShoppingPL3);
        ShoppingConvoPL3.setText(getString(R.string.ShoppingConversationPL7) + "\n \n"+ getString(R.string.ShoppingConversationPL8) +
                "\n \n" + getString(R.string.ShoppingConversationPL9));
        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG3 = (ImageButton) findViewById(R.id.btn_PushToListenShoppingTalkENG3);
        btnClickToListenENG3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.ShoppingConversationENG7),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.ShoppingConversationENG8),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.ShoppingConversationENG9),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
