package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class ShoppingTalksTwo extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Button btnBackToShopping2, btnNextShoppingTalks2;
    ImageButton btnClickToListenENG2;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_talks_two);

        btnNextShoppingTalks2 = (Button) findViewById(R.id.btn_NextShoppingTalk2);
        btnNextShoppingTalks2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksTwo.this, ShoppingTalksThree.class);
                startActivity(intent);

            }
        });

        btnBackToShopping2 = (Button) findViewById(R.id.btn_BackToShopping2);
        btnBackToShopping2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(ShoppingTalksTwo.this, ShoppingTalksOne.class);
                startActivity(intent);

            }
        });

        TextView ShoppingConvoENG2;

        ShoppingConvoENG2 = findViewById(R.id.TransportShoppingENG2);
        ShoppingConvoENG2.setText(getString(R.string.ShoppingConversationENG4) + "\n \n"+ getString(R.string.ShoppingConversationENG5) +
                "\n \n" + getString(R.string.ShoppingConversationENG6));

        TextView ShoppingConvoPL2;

        ShoppingConvoPL2 = findViewById(R.id.TransportShoppingPL2);
        ShoppingConvoPL2.setText(getString(R.string.ShoppingConversationPL4) + "\n \n"+ getString(R.string.ShoppingConversationPL5) +
                "\n \n" + getString(R.string.ShoppingConversationPL6));

        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG2 = (ImageButton) findViewById(R.id.btn_PushToListenShoppingTalkENG2);
        btnClickToListenENG2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.ShoppingConversationENG4),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.ShoppingConversationENG5),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.ShoppingConversationENG6),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });
    }
    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
