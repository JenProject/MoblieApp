package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class SightseeTalksOne extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button btnBackToSightsee1, btnNextSighteeTalks1;
    ImageButton btnClickToListenENG1;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sightsee_talks_one);

        btnBackToSightsee1 = (Button) findViewById(R.id.btn_BackToSightsee1);
        btnNextSighteeTalks1 = (Button) findViewById(R.id.btn_NextSightseeTalk1);

        btnBackToSightsee1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SightseeTalksOne.this, SightseeChosen.class);
                startActivity(intent);

            }
        });

        btnNextSighteeTalks1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SightseeTalksOne.this, SightseeTalksTwo.class);
                startActivity(intent);

            }
        });

        TextView SightseeConvoENG1;

        SightseeConvoENG1 = findViewById(R.id.TransportSightseeENG1);
        SightseeConvoENG1.setText(getString(R.string.SightseeConversationENG1) + "\n \n" + getString(R.string.SightseeConversationENG2) +
                "\n \n" + getString(R.string.SightseeConversationENG3));

        TextView SightseeConvoPL1;

        SightseeConvoPL1 = findViewById(R.id.TransportSightseePL1);
        SightseeConvoPL1.setText(getString(R.string.SightseeConversationPL1) + "\n \n" + getString(R.string.SightseeConversationPL2) +
                "\n \n" + getString(R.string.SightseeConversationPL3));

        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG1 = (ImageButton) findViewById(R.id.btn_PushToListenSightseeTalkENG1);
        btnClickToListenENG1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.speak(getString(R.string.SightseeConversationENG1),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.SightseeConversationENG2),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.SightseeConversationENG3),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });

    }

    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub

    }
}


