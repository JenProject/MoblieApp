package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class SightseeTalksTwo extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button btnBackToSightsee2, btnNextSighseetalks2;
    ImageButton btnClickToListenENG2;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sightsee_talks_two);

        btnBackToSightsee2 = (Button) findViewById(R.id.btn_BackToSightsee2);
        btnNextSighseetalks2 = (Button) findViewById(R.id.btn_NextSightseeTalk2);

        btnBackToSightsee2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SightseeTalksTwo.this, SightseeTalksOne.class);
                startActivity(intent);

            }
        });

        btnNextSighseetalks2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SightseeTalksTwo.this, SightseeTalksThree.class);
                startActivity(intent);

            }
        });

        TextView SightseeConvoENG2;

        SightseeConvoENG2 = findViewById(R.id.TransportSightseeENG2);
        SightseeConvoENG2.setText(getString(R.string.SightseeConversationENG4) + "\n \n" + getString(R.string.SightseeConversationENG5) +
                "\n \n" + getString(R.string.SightseeConversationENG6));

        TextView SightseeConvoPL2;

        SightseeConvoPL2 = findViewById(R.id.TransportSightseePL2);
        SightseeConvoPL2.setText(getString(R.string.SightseeConversationPL4) + "\n \n" + getString(R.string.SightseeConversationPL5) +
                "\n \n" + getString(R.string.TransportConversationPL6));
        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG2 = (ImageButton) findViewById(R.id.btn_PushToListenSightseeTalkENG2);
        btnClickToListenENG2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.speak(getString(R.string.SightseeConversationENG4),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.SightseeConversationENG5),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.SightseeConversationENG6),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });

    }

    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
