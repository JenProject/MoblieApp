package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapter extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapter(Context context){
        this.context = context;
    }

    // Transport Scroll View
    public int[] TransportPage1 = {
            R.drawable.passport,
            R.drawable.selfluggage,
            R.drawable.airplanelanding
    };
    public String[] TransportHeadings1 = {
            "paszport  passport ",
            "self-luggage  bagaż podręczny",
            "arrivals  przyloty "
    };

    public int[] TransportPage2 = {
            R.drawable.boardingpass,
            R.drawable.bagaz,
            R.drawable.airplanestart
    };
    public String[] TransportHeadings2 = {
            "boarding-pass  karta pokładowa ",
            "luggage  bagaż ",
            "departures  odloty",
    };
    public int[] TransportPage3 = {
            R.drawable.ticket,
            R.drawable.policemanfemale,
            R.drawable.sit
    };
    public String[] TransportHeadings3 = {
            "ticket  bilet",
            "passport control  kontrola paszportowa",
            "sit  siedzenie"
    };



    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public boolean isViewFromObject(View view,  Object o) {
        return view == (RelativeLayout) o;
    };


    @Override
    public Object instantiateItem( ViewGroup container, int position) {
        //   return super.instantiateItem(container, position);
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);
        View viewSec = layoutInflater.inflate(R.layout.slide_layout, container,false);
        View viewTh = layoutInflater.inflate(R.layout.slide_layout,container,false);

        CreateVocabTransp(view,position);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object) {
        // super.destroyItem(container, position, object);
        container.removeView((RelativeLayout)object);
    }

    public void CreateVocabTransp(View view, int position){
        ImageView slideView1 = (ImageView) view.findViewById(R.id.slideView1);
        ImageView slideView2 = (ImageView) view.findViewById(R.id.slideView);
        ImageView slideView3 = (ImageView) view.findViewById(R.id.slideView2);
        slideView1.setImageResource(TransportPage1[position]);
        slideView2.setImageResource(TransportPage2[position]);
        slideView3.setImageResource(TransportPage3[position]);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        TextView textView1 = (TextView) view.findViewById(R.id.textView2);
        TextView textView2 = (TextView) view.findViewById(R.id.textView3);
        textView.setText(TransportHeadings1[position]);
        textView1.setText(TransportHeadings2[position]);
        textView2.setText(TransportHeadings3[position]);

    }
}