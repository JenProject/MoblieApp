package com.example.myapplication;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapterFood extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapterFood(Context context){
        this.context = context;
    }

    // Transport Scroll View

    // Medicine Scroll View
    public int[] FoodPage1 = {
            R.drawable.meal,
            R.drawable.starter,
            R.drawable.plate
    };
    public String[] FoodHeadings1 = {
            "meal      posiłek ",
            "starters  przystawki",
            "plate     tależ"
    };
    public int[] FoodPage2 = {
            R.drawable.maincourse,
            R.drawable.drink,
            R.drawable.bill
    };
    public String[] FoodHeadings2 = {
            "main course  główne danie",
            "drink       napój",
            "bill       rachunek",
    };
    public int[] FoodPage3 = {
            R.drawable.fork,
            R.drawable.spoon,
            R.drawable.napkin
    };
    public String[] FoodHeadings3 = {
            "fork       widelec",
            "spoon      łyżka",
            "napkin     serwetka"
    };


    @Override
    public int getCount() {
        return FoodHeadings3.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return view == (RelativeLayout) o;
    };


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        //   return super.instantiateItem(container, position);
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);
        View viewSec = layoutInflater.inflate(R.layout.slide_layout, container,false);
        View viewTh = layoutInflater.inflate(R.layout.slide_layout,container,false);


        CreateVocabMedic(view,position);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object) {
        // super.destroyItem(container, position, object);
        container.removeView((RelativeLayout)object);
    }

    public void CreateVocabMedic(View view, int position){
        ImageView slideView1 = (ImageView) view.findViewById(R.id.slideView1);
        ImageView slideView2 = (ImageView) view.findViewById(R.id.slideView);
        ImageView slideView3 = (ImageView) view.findViewById(R.id.slideView2);
        slideView1.setImageResource(FoodPage1[position]);
        slideView2.setImageResource(FoodPage2[position]);
        slideView3.setImageResource(FoodPage3[position]);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        TextView textView1 = (TextView) view.findViewById(R.id.textView2);
        TextView textView2 = (TextView) view.findViewById(R.id.textView3);
        textView.setText(FoodHeadings1[position]);
        textView1.setText(FoodHeadings2[position]);
        textView2.setText(FoodHeadings3[position]);

    }
}
