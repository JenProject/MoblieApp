package com.example.myapplication;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapterShopping extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapterShopping(Context context){
        this.context = context;
    }

    public int[] ShopPage1 = {
            R.drawable.shoppingmall,
            R.drawable.buy,
            R.drawable.discount
    };
    public String[] ShopHeadings1 = {
            "shopping mall  centrum handlowe",
            "buy  kupować",
            "discount  zniżka"
    };
    public int[] ShopPage2 = {
            R.drawable.market,
            R.drawable.shelf,
            R.drawable.price
    };
    public String[] ShopHeadings2 = {
            "market  rynek",
            "market shelf  półka sklepowa",
            "price       cena",
    };
    public int[] ShopPage3 = {
            R.drawable.samovar,
            R.drawable.sale,
            R.drawable.seller
    };
    public String[] ShopHeadings3 = {
            "souvenir  pamiątka",
            "sale  wyprzedaż",
            "seller  sprzedawca"
    };


    @Override
    public int getCount() {
        return ShopHeadings3.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return view == (RelativeLayout) o;
    };


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        //   return super.instantiateItem(container, position);
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);
        View viewSec = layoutInflater.inflate(R.layout.slide_layout, container,false);
        View viewTh = layoutInflater.inflate(R.layout.slide_layout,container,false);


        CreateVocabMedic(view,position);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object) {
        // super.destroyItem(container, position, object);
        container.removeView((RelativeLayout)object);
    }

    public void CreateVocabMedic(View view, int position){
        ImageView slideView1 = (ImageView) view.findViewById(R.id.slideView1);
        ImageView slideView2 = (ImageView) view.findViewById(R.id.slideView);
        ImageView slideView3 = (ImageView) view.findViewById(R.id.slideView2);
        slideView1.setImageResource(ShopPage1[position]);
        slideView2.setImageResource(ShopPage2[position]);
        slideView3.setImageResource(ShopPage3[position]);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        TextView textView1 = (TextView) view.findViewById(R.id.textView2);
        TextView textView2 = (TextView) view.findViewById(R.id.textView3);
        textView.setText(ShopHeadings1[position]);
        textView1.setText(ShopHeadings2[position]);
        textView2.setText(ShopHeadings3[position]);

    }
}
