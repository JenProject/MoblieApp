package com.example.myapplication;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SliderAdapterSight extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapterSight(Context context){
        this.context = context;
    }

    // Transport Scroll View

    // Medicine Scroll View
    public int[] SightSeePage1 = {
            R.drawable.monument,
            R.drawable.ticketpass,
            R.drawable.broshure
    };
    public String[] SightSeeHeadings1 = {
            "monument   zabytek",
            "pass     wejściówka",
            "information brochure  broszura informacyjna"
    };
    public int[] SightSeePage2 = {
            R.drawable.guidebook,
            R.drawable.path,
            R.drawable.trip
    };
    public String[] SightSeeHeadings2 = {
            "guidebook  przewodnik",
            "path     ścieżka",
            "trip     wycieczka",
    };
    public int[] SightSeePage3 = {
            R.drawable.museum,
            R.drawable.sightsee,
            R.drawable.optionaltrip
    };
    public String[] SightSeeHeadings3 = {
            "museum     muzeum",
            "sightsee    zwiedzać",
            "optional trip  wycieczka fakultatywna"
    };


    @Override
    public int getCount() {
        return SightSeeHeadings3.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return view == (RelativeLayout) o;
    };


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        //   return super.instantiateItem(container, position);
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);
        View viewSec = layoutInflater.inflate(R.layout.slide_layout, container,false);
        View viewTh = layoutInflater.inflate(R.layout.slide_layout,container,false);


        CreateVocabMedic(view,position);

        container.addView(view);

        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object) {
        // super.destroyItem(container, position, object);
        container.removeView((RelativeLayout)object);
    }

    public void CreateVocabMedic(View view, int position){
        ImageView slideView1 = (ImageView) view.findViewById(R.id.slideView1);
        ImageView slideView2 = (ImageView) view.findViewById(R.id.slideView);
        ImageView slideView3 = (ImageView) view.findViewById(R.id.slideView2);
        slideView1.setImageResource(SightSeePage1[position]);
        slideView2.setImageResource(SightSeePage2[position]);
        slideView3.setImageResource(SightSeePage3[position]);

        TextView textView = (TextView) view.findViewById(R.id.textView);
        TextView textView1 = (TextView) view.findViewById(R.id.textView2);
        TextView textView2 = (TextView) view.findViewById(R.id.textView3);
        textView.setText(SightSeeHeadings1[position]);
        textView1.setText(SightSeeHeadings2[position]);
        textView2.setText(SightSeeHeadings3[position]);

    }
}
