package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.speech.tts.TextToSpeech.OnInitListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TransportTalks extends AppCompatActivity implements OnInitListener {

    Button btnBackToTransport1, btnNextTransportTalks1;
    ImageButton btnClickToListenENG1, btnClickToListenPL1;
    private TextToSpeech tts, tts2, tts3, tts4, tts5, tts6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transport_talks);

        btnBackToTransport1 = (Button) findViewById(R.id.btn_BackToTransport1);
        btnNextTransportTalks1 = (Button) findViewById(R.id.btn_NextTransportTalk1);

        btnBackToTransport1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalks.this, CategoryChosen1.class);
                startActivity(intent);

            }
        });

        btnNextTransportTalks1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalks.this, TransportTalksPartTwo.class);
                startActivity(intent);

            }
        });

        TextView TrasnportConvoENG1;

        TrasnportConvoENG1 = findViewById(R.id.TransportTalksENG1);
        TrasnportConvoENG1.setText(getString(R.string.TransportConversationENG1) + "\n \n"+ getString(R.string.TransportConversationENG2) +
                "\n \n" + getString(R.string.TransportConversationENG3));

        TextView TrasnportConvoPL1;

        TrasnportConvoPL1 = findViewById(R.id.TransportTalksPL1);
        TrasnportConvoPL1.setText(getString(R.string.TransportConversationPL1) + "\n \n"+ getString(R.string.TransportConversationPL2) +
                "\n \n" + getString(R.string.TransportConversationPL3));



        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result4 = tts.setLanguage(Locale.US);
        int result5 = tts2.setLanguage(Locale.US);
        int result6 = tts3.setLanguage(Locale.US);

        btnClickToListenENG1 = (ImageButton) findViewById(R.id.btn_PushToListenTransportTalkENG1);
        btnClickToListenENG1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.TransportConversationENG1),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.TransportConversationENG2),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.TransportConversationENG3),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });


    }

    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }

    }








