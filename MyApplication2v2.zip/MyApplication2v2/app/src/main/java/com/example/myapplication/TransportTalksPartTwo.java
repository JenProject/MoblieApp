package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class TransportTalksPartTwo extends AppCompatActivity implements TextToSpeech.OnInitListener {


    Button btnBackToTransport2, btnNextTransportTalks2;
    ImageButton btnClickToListenENG2;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transport_talks_part_two);

        btnBackToTransport2 = (Button) findViewById(R.id.btn_BackToTransport2);
        btnNextTransportTalks2 = (Button) findViewById(R.id.btn_NextTransportTalk2);

        btnBackToTransport2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalksPartTwo.this, TransportTalks.class);
                startActivity(intent);

            }
        });

        btnNextTransportTalks2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalksPartTwo.this, TransportTalksThree.class);
                startActivity(intent);

            }
        });

        TextView TrasnportConvoENG2;

        TrasnportConvoENG2 = findViewById(R.id.TransportTalksENG2);
        TrasnportConvoENG2.setText(getString(R.string.TransportConversationENG4) + "\n \n"+ getString(R.string.TransportConversationENG5) +
                "\n \n" + getString(R.string.TransportConversationENG6));

        TextView TrasnportConvoPL2;

        TrasnportConvoPL2 = findViewById(R.id.TransportTalksPL2);
        TrasnportConvoPL2.setText(getString(R.string.TransportConversationPL4) + "\n \n"+ getString(R.string.TransportConversationPL5) +
                "\n \n" + getString(R.string.TransportConversationPL6));


        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG2 = (ImageButton) findViewById(R.id.btn_PushToListenTransportTalkENG2);
        btnClickToListenENG2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.TransportConversationENG4),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.TransportConversationENG5),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.TransportConversationENG6),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });


    }

    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}


