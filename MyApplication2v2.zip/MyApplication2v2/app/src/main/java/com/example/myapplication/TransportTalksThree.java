package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class TransportTalksThree extends AppCompatActivity implements TextToSpeech.OnInitListener {

    Button btnBackToMenu, btnBackToTransport3;
    ImageButton btnClickToListenENG3;
    TextToSpeech tts, tts2, tts3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transport_talks_three);

        btnBackToTransport3 = (Button) findViewById(R.id.btn_BackToTransport3);
        btnBackToMenu = (Button) findViewById(R.id.btn_BackToMenu);

        btnBackToTransport3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalksThree.this, TransportTalksPartTwo.class);
                startActivity(intent);

            }
        });

        btnBackToMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(TransportTalksThree.this, MainActivity.class);
                startActivity(intent);

            }
        });

        TextView TrasnportConvoENG3;

        TrasnportConvoENG3 = findViewById(R.id.TransportTalksENG3);
        TrasnportConvoENG3.setText(getString(R.string.TransportConversationENG7) + "\n \n"+ getString(R.string.TransportConversationENG8) +
                "\n \n" + getString(R.string.TransportConversationENG9));

        TextView TrasnportConvoPL3;

        TrasnportConvoPL3 = findViewById(R.id.TransportTalksPL3);
        TrasnportConvoPL3.setText(getString(R.string.TransportConversationPL7) + "\n \n"+ getString(R.string.TransportConversationPL8) +
                "\n \n" + getString(R.string.TransportConversationPL9));

        tts = new TextToSpeech(this, this);
        tts2 = new TextToSpeech(this, this);
        tts3 = new TextToSpeech(this, this);

        int result1 = tts.setLanguage(Locale.US);
        int result2 = tts2.setLanguage(Locale.US);
        int result3 = tts3.setLanguage(Locale.US);

        btnClickToListenENG3 = (ImageButton) findViewById(R.id.btn_PushToListenTransportTalkENG3);
        btnClickToListenENG3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                tts.speak(getString(R.string.TransportConversationENG7),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts2.speak(getString(R.string.TransportConversationENG8),
                        TextToSpeech.QUEUE_FLUSH, null);
                tts3.speak(getString(R.string.TransportConversationENG9),
                        TextToSpeech.QUEUE_FLUSH, null);
            }

        });

    }

    @Override
    public void onInit(int arg0) {
        // TODO Auto-generated method stub
    }
}
