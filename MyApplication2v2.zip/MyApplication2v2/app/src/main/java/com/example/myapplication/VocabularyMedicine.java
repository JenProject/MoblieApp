package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class VocabularyMedicine extends AppCompatActivity {

    private ImageButton back;
    private ViewPager SlideViewPager;



    private SliderAdapterMed sliderAdapter1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary_medicine);
        back = (ImageButton) findViewById(R.id.btn_GetBack);
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(VocabularyMedicine.this, MedicChosen.class);
                startActivity(intent);
            }

        });

        SlideViewPager = (ViewPager) findViewById(R.id.ViewPagerM);

        sliderAdapter1 = new SliderAdapterMed(this);

        SlideViewPager.setAdapter(sliderAdapter1);
    }
}
