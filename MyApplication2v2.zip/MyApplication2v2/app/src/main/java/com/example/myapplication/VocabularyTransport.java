package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class VocabularyTransport extends AppCompatActivity {

    private ImageButton back;
    private ViewPager SlideViewPager;



    private SliderAdapter sliderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary_transport);
        back = (ImageButton) findViewById(R.id.btn_GetBack);
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(VocabularyTransport.this, CategoryChosen1.class);
                startActivity(intent);
            }

        });

        SlideViewPager = (ViewPager) findViewById(R.id.ViewPagerM);

        sliderAdapter = new SliderAdapter(this);

        SlideViewPager.setAdapter(sliderAdapter);

    }
}